# Resume Screener

Analyzes resumes against job descriptions with Excel output.

## Features
- Supports 11 job descriptions (DESE/NIMT roles).
- Processes PDF, DOCX, TXT resumes.
- Outputs results as Excel.
- Simple Streamlit UI.
- Shareable Python project.

## Prerequisites
- Python 3.9+
- Internet for API access

## Setup
1. Clone or download to `C:\stealth\Resume_Screener`.
2. Create virtual environment:
   ```powershell
   python -m venv venv
   .\venv\Scripts\activate