import streamlit as st
from io import BytesIO
import pandas as pd
from pathlib import Path

def run_ui(job_descriptions, process_resumes, test_api_connectivity, api_config, processing_config):
    st.title("Resume Analysis Tool")
    st.write("Upload resumes and analyze them against a selected job description.")

    # Job Description Selection
    jd_options = list(job_descriptions.keys())
    selected_jd = st.selectbox("Select Job Description", jd_options, index=0)

    # File Upload
    uploaded_files = st.file_uploader("Upload Resumes (PDF, DOCX, TXT)", accept_multiple_files=True, type=processing_config['supported_extensions'])
    if uploaded_files:
        st.write(f"Uploaded {len(uploaded_files)} files.")

    # Process Button
    if st.button("Analyze Resumes"):
        if uploaded_files:
            if not test_api_connectivity(api_config['url'], api_config['headers']):
                st.error("API connectivity test failed. Check logs or proceed manually.")
            else:
                with st.spinner("Analyzing resumes..."):
                    df = process_resumes(
                        uploaded_files, 
                        selected_jd,
                        job_descriptions,
                        api_config['url'],
                        api_config['headers'],
                        processing_config['max_file_size_mb'],
                        api_config['request_delay']
                    )
                    if df is not None:
                        st.success("Analysis completed!")
                        st.dataframe(df)

                        # Download button
                        output = BytesIO()
                        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                            df.to_excel(writer, sheet_name='Resume Analysis', index=False)
                        output.seek(0)
                        st.download_button(
                            label="Download Results as Excel",
                            data=output,
                            file_name=processing_config['output_excel'],
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        )
                    else:
                        st.error("No results generated. Check logs for errors.")
        else:
            st.warning("Please upload at least one resume file.")

    # Display Logs (for debugging)
    with st.expander("View Logs"):
        log_file = Path('logs') / 'resume_processor.log'
        if log_file.exists():
            with open(log_file, 'r') as f:
                st.text(f.read())
        else:
            st.write("No logs available yet.")

    st.write("Developed by Capgemini")